# Auto-generated for lazy_import_all_from
__all__ = [
    'uv_map',
    'pixel_coord_map',
    'screen_coord_map',
    'build_mesh_from_map',
    'build_mesh_from_depth_map',
    'depth_map_edge',
    'depth_map_aliasing',
    'normal_map_edge',
    'point_map_to_normal_map',
    'depth_map_to_point_map',
    'depth_map_to_normal_map',
    'chessboard',
    'masked_nearest_resize',
    'masked_area_resize',
    'colorize_depth_map',
    'colorize_normal_map',
]
